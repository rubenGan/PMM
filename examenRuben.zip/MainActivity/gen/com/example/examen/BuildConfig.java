/** Automatically generated file. DO NOT MODIFY */
package com.example.examen;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}