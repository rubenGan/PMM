package com.example.examen;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class Cronometro extends Activity{
	
	int segundos=0;
	int minutos=0;
	int horas=0;
	
	

	

	
	 @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.cronometro);
	        final EditText crono=(EditText)findViewById(R.id.editText1);
	        
	        crono.setText(horas+":"+minutos+":"+segundos);
	       

	        
	        final Button btnArranca = (Button)findViewById(R.id.arrancar);
	        btnArranca.setOnClickListener(new OnClickListener(){
	        	public void onClick(View view) {
	        		
	        		boolean bucle=true;
	        		
	        			try {
	        				while(bucle){
							Thread.sleep(999);
							unSegundoMas();
		        			crono.setText(horas+":"+minutos+":"+segundos);
	        				
		        			if(btnArranca.isPressed())
		        				bucle=false;
	        				}	
		        		
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
	        			
	        		
	        		
	        		
	        	}
	        });
	        Button btnParar=(Button)findViewById(R.id.parar);
	        btnParar.setOnClickListener(new OnClickListener(){
	        	public void onClick(View view){
	        		
	        		 segundos=0;
	        		 minutos=0;
	        		 horas=0;
	        		
	        		 crono.setText(horas+":"+minutos+":"+segundos);
	        		
	        		
	        	}
	        });
	        
	  
	
	    }
	 
	 public void unSegundoMas(){
		 segundos++;
		 if(segundos==60){
			 segundos=0;
			 minutos++;
			 if(minutos==60){
				 minutos=0;
				 horas++;
				 if(horas==24)
					 horas=0;
			 }
		 }
     	
     }
	 

}
